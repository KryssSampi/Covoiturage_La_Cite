"""
Talki — Service CamemBERT :8001
Classification d'intention + génération d'embeddings sémantiques.
Modèle de base : camembert-base (Inria/Facebook, open source, gratuit)
Fine-tuning continu : rechargé chaque nuit après entraînement.

Endpoints :
  POST /classify    → intent + entity + scores depuis texte français
  POST /embed       → vecteur sémantique 768 dims
  POST /reload      → recharge le modèle fine-tuné depuis disque
  GET  /health      → statut
"""

from __future__ import annotations
import os
import json
import time
import pickle
from pathlib import Path

import torch
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from transformers import (
    CamembertTokenizer,
    CamembertForSequenceClassification,
    AutoModel, AutoTokenizer,
)

app = FastAPI(title="Talki — Service CamemBERT", version="1.0.0")

# ── Chemins
DATA_DIR         = Path(__file__).parent / "data"
CLASSIFIER_PATH  = DATA_DIR / "camembert_classifier"   # sauvegardé après fine-tuning
EMBEDDER_ID      = "camembert-base"                    # pour les embeddings
BASE_MODEL_ID    = "camembert-base"

# ── Intents du système (même liste que models.py)
INTENT_LABELS = [
    "reservation", "annulation", "paiement", "compte", "trajet",
    "conducteur", "passager", "signalement", "litige", "vehicule",
    "notifications", "indisponibilite", "securite",
    "hors_scope", "salutation", "incomprehensible",
]

ENTITY_LABELS = [
    "trajet", "reservation", "paiement", "compte",
    "vehicule", "profil", "badge", "review", "aucun",
]


# ─────────────────────────────────────────────
#  ÉTAT DU SERVICE
# ─────────────────────────────────────────────

class ModelState:
    classifier_tokenizer = None
    classifier_model     = None
    embedder_tokenizer   = None
    embedder_model       = None
    intent_labels        = INTENT_LABELS
    entity_labels        = ENTITY_LABELS
    fine_tuned           = False

state = ModelState()


def _load_classifier():
    """
    Charge le classifieur CamemBERT.
    Si un modèle fine-tuné existe → l'utilise.
    Sinon → fallback sur règles (avant premier entraînement).
    """
    if CLASSIFIER_PATH.exists():
        print(f"[CamemBERT] Chargement classifieur fine-tuné depuis {CLASSIFIER_PATH}")
        state.classifier_tokenizer = CamembertTokenizer.from_pretrained(str(CLASSIFIER_PATH))
        state.classifier_model     = CamembertForSequenceClassification.from_pretrained(
            str(CLASSIFIER_PATH)
        )
        state.classifier_model.eval()
        state.fine_tuned = True
    else:
        print("[CamemBERT] Pas de modèle fine-tuné — mode règles actif jusqu'au 1er entraînement")
        state.fine_tuned = False


def _load_embedder():
    """Charge le modèle d'embeddings (camembert-base)."""
    print(f"[CamemBERT] Chargement embedder {EMBEDDER_ID}...")
    start = time.time()
    state.embedder_tokenizer = AutoTokenizer.from_pretrained(EMBEDDER_ID)
    state.embedder_model     = AutoModel.from_pretrained(EMBEDDER_ID)
    state.embedder_model.eval()
    print(f"[CamemBERT] Embedder chargé en {time.time()-start:.1f}s")


# ─────────────────────────────────────────────
#  CLASSIFICATION PAR RÈGLES (fallback avant fine-tuning)
# ─────────────────────────────────────────────

INTENT_KEYWORDS: dict[str, list[str]] = {
    "reservation":    ["reserver", "reservation", "booker", "place", "passager",
                       "chercher trajet", "trouver trajet", "faire reservation",
                       "prendre place", "book"],
    "annulation":     ["annuler", "annulation", "supprimer", "cancel", "desister",
                       "ne veux plus", "plus y aller"],
    "paiement":       ["payer", "paiement", "carte", "refuse", "remboursement",
                       "recharger", "argent", "retrait", "transaction", "solde",
                       "gains", "virement", "depot", "finances"],
    "compte":         ["compte", "connexion", "login", "profil", "supprimer compte",
                       "microsoft", "sso", "se connecter", "inscription", "creer compte"],
    "trajet":         ["trajet", "creer trajet", "publier", "covoiturage", "matching",
                       "offrir place", "nouveau trajet", "poster trajet"],
    "conducteur":     ["conducteur", "chauffeur", "offrir", "conduire", "driver"],
    "passager":       ["passager", "voyager", "cherche", "rider"],
    "signalement":    ["signaler", "signalement", "report", "plainte", "comportement"],
    "litige":         ["litige", "contester", "dispute", "no-show", "contestation"],
    "vehicule":       ["vehicule", "voiture", "auto", "plaque", "assurance"],
    "notifications":  ["notification", "alerte", "desactiver", "activer"],
    "indisponibilite":["indisponible", "absent", "conge", "bloquer dates"],
    "securite":       ["urgence", "sos", "danger", "peur", "securite", "911"],
    "salutation":     ["bonjour", "salut", "allo", "hello", "hey", "hi", "bonsoir",
                       "merci", "au revoir", "bye", "bonne journee", "good morning",
                       "good evening", "how are you", "comment vas", "ca va",
                       "good afternoon", "good night"],
    "hors_scope":     ["horoscope", "meteo", "blague", "recette", "nouvelles", "sport",
                       "film", "musique", "cuisine", "politique"],
}

ENTITY_KEYWORDS: dict[str, list[str]] = {
    "reservation":  ["réservation", "réserver", "booking"],
    "paiement":     ["paiement", "carte", "argent", "remboursement"],
    "compte":       ["compte", "profil", "connexion"],
    "trajet":       ["trajet", "covoiturage", "route"],
    "vehicule":     ["véhicule", "voiture", "auto"],
    "review":       ["évaluation", "note", "avis", "étoiles"],
}


def _normalize(text: str) -> str:
    """Supprime accents et met en minuscule pour matching robuste."""
    import unicodedata
    return "".join(
        c for c in unicodedata.normalize("NFD", text.lower())
        if unicodedata.category(c) != "Mn"
    )


def _classify_by_rules(text: str) -> dict:
    """
    Classification par overlap de mots-clés — actif avant le 1er fine-tuning.
    Matching insensible aux accents et à la casse.
    """
    text_norm = _normalize(text)
    best_intent, best_score = "incomprehensible", 0

    for intent, keywords in INTENT_KEYWORDS.items():
        score = sum(1 for kw in keywords if kw in text_norm)
        if score > best_score:
            best_score, best_intent = score, intent

    best_entity, best_entity_score = "aucun", 0
    for entity, keywords in ENTITY_KEYWORDS.items():
        kw_norm = [_normalize(k) for k in keywords]
        score = sum(1 for kw in kw_norm if kw in text_norm)
        if score > best_entity_score:
            best_entity_score, best_entity = score, entity

    return {
        "intent":       best_intent,
        "intent_score": min(best_score / 3.0, 1.0),
        "entity":       best_entity,
        "entity_score": min(best_entity_score / 2.0, 1.0),
        "method":       "rules",
    }


def _classify_by_model(text: str) -> dict:
    """Classification via CamemBERT fine-tuné."""
    inputs = state.classifier_tokenizer(
        text, return_tensors="pt", truncation=True, max_length=128, padding=True
    )
    with torch.no_grad():
        logits = state.classifier_model(**inputs).logits

    probs     = torch.softmax(logits, dim=-1)[0]
    intent_id = probs.argmax().item()
    intent    = state.intent_labels[intent_id] if intent_id < len(state.intent_labels) else "incomprehensible"

    return {
        "intent":       intent,
        "intent_score": float(probs[intent_id]),
        "entity":       "aucun",   # entité déduite par règles complémentaires
        "entity_score": 0.0,
        "method":       "camembert",
    }


# ─────────────────────────────────────────────
#  EMBEDDINGS
# ─────────────────────────────────────────────

def _mean_pooling(model_output, attention_mask) -> torch.Tensor:
    token_embeddings = model_output.last_hidden_state
    input_mask = attention_mask.unsqueeze(-1).expand(token_embeddings.size()).float()
    return torch.sum(token_embeddings * input_mask, 1) / torch.clamp(input_mask.sum(1), min=1e-9)


def _embed(text: str) -> list[float]:
    if state.embedder_model is None:
        return []
    inputs = state.embedder_tokenizer(
        text, return_tensors="pt", truncation=True, max_length=128, padding=True
    )
    with torch.no_grad():
        output = state.embedder_model(**inputs)
    vec = _mean_pooling(output, inputs["attention_mask"])
    return vec[0].tolist()


# ─────────────────────────────────────────────
#  SCHÉMAS
# ─────────────────────────────────────────────

class ClassifyRequest(BaseModel):
    text: str   # Texte en français (déjà traduit par :8002)

class EmbedRequest(BaseModel):
    text: str


# ─────────────────────────────────────────────
#  ENDPOINTS
# ─────────────────────────────────────────────

@app.post("/classify")
def classify(req: ClassifyRequest):
    """
    Classifie un texte français → intent + entity + scores.
    Utilise CamemBERT si fine-tuné, sinon règles.
    """
    if not req.text.strip():
        raise HTTPException(status_code=400, detail="Texte vide")

    if state.fine_tuned and state.classifier_model:
        result = _classify_by_model(req.text)
    else:
        result = _classify_by_rules(req.text)

    # Enrichissement entity par règles (rapide, complémentaire)
    if result["entity"] == "aucun":
        rules = _classify_by_rules(req.text)
        result["entity"]       = rules["entity"]
        result["entity_score"] = rules["entity_score"]

    # Flags utiles pour le pipeline
    result["is_out_of_scope"] = result["intent"] == "hors_scope"
    result["is_small_talk"]   = result["intent"] == "salutation"
    result["text"]            = req.text

    return result


@app.post("/embed")
def embed(req: EmbedRequest):
    """Retourne le vecteur sémantique 768 dims d'un texte français."""
    if not req.text.strip():
        raise HTTPException(status_code=400, detail="Texte vide")
    vec = _embed(req.text)
    return {"vector": vec, "dimensions": len(vec)}


@app.post("/reload")
def reload_model():
    """
    Recharge le modèle fine-tuné depuis disque.
    Appelé par le Training Loop après chaque cycle nocturne réussi.
    """
    _load_classifier()
    return {
        "status":     "reloaded",
        "fine_tuned": state.fine_tuned,
        "method":     "camembert" if state.fine_tuned else "rules",
    }


@app.get("/health")
def health():
    return {
        "status":          "healthy",
        "fine_tuned":      state.fine_tuned,
        "embedder_ready":  state.embedder_model is not None,
        "classifier_path": str(CLASSIFIER_PATH),
        "method":          "camembert" if state.fine_tuned else "rules",
    }


@app.on_event("startup")
def startup():
    _load_classifier()
    _load_embedder()
    print("[CamemBERT] ✓ Service Talki prêt sur :8001")


# uvicorn camembert_service:app --port 8001
