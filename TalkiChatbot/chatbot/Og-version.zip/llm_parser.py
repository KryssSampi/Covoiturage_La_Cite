"""
Talki — Parser
Transforme le texte brut (déjà en français) → QuestionObject structuré.
Appelle CamemBERT local :8001 — zéro API externe, zéro coût.
"""

from __future__ import annotations
import httpx
from models import QuestionObject, Intent, Entity

CAMEMBERT_URL = "http://localhost:8001"
TIMEOUT       = 5.0


def parse_question(text_fr: str) -> QuestionObject:
    """
    Le texte est déjà traduit en français par le service NLLB avant cet appel.
    CamemBERT classifie l'intention et l'entité.
    """
    try:
        r = httpx.post(f"{CAMEMBERT_URL}/classify", json={"text": text_fr}, timeout=TIMEOUT)
        r.raise_for_status()
        data = r.json()

        try:
            intent = Intent(data.get("intent", "incomprehensible"))
            entity = Entity(data.get("entity", "aucun"))
        except ValueError:
            intent, entity = Intent.INCOMPREHENSIBLE, Entity.AUCUN

        return QuestionObject(
            raw_text          = text_fr,
            intent            = intent,
            entity            = entity,
            urgency_score     = 0.95 if intent == Intent.SECURITE else 0.2,
            ambiguity_score   = max(0.0, 1.0 - float(data.get("intent_score", 0.5))),
            domain_relevance  = 0.0 if intent in {Intent.HORS_SCOPE, Intent.SALUTATION, Intent.INCOMPREHENSIBLE} else 0.90,
            keywords          = _keywords(text_fr),
            is_small_talk     = bool(data.get("is_small_talk", False)),
            is_out_of_scope   = bool(data.get("is_out_of_scope", False)),
            context_variables = {},
        )

    except Exception as e:
        print(f"[Parser] Fallback règles — {e}")
        return _fallback(text_fr)


def get_embedding(text_fr: str) -> list[float]:
    """Vecteur sémantique 768 dims depuis CamemBERT."""
    try:
        r = httpx.post(f"{CAMEMBERT_URL}/embed", json={"text": text_fr}, timeout=TIMEOUT)
        r.raise_for_status()
        return r.json().get("vector", [])
    except Exception:
        return []


def is_domain_relevant(qobj: QuestionObject, threshold: float = 0.40) -> bool:
    if qobj.is_out_of_scope or qobj.is_small_talk:
        return False
    return qobj.domain_relevance >= threshold


def _keywords(text: str) -> list[str]:
    stop = {"le","la","les","de","du","des","un","une","je","tu","il","elle",
            "nous","vous","ils","et","en","à","au","par","sur","pour","pas","ne","mon","ma","mes"}
    return [w for w in text.lower().split() if len(w) > 3 and w not in stop][:10]


def _fallback(raw_text: str) -> QuestionObject:
    return QuestionObject(
        raw_text=raw_text, intent=Intent.INCOMPREHENSIBLE, entity=Entity.AUCUN,
        urgency_score=0.0, ambiguity_score=1.0, domain_relevance=0.0,
        keywords=[], is_small_talk=False, is_out_of_scope=False, context_variables={},
    )
